OpenCV Face Count

This project demonstrates how to use OpenCV to detect faces in images and count the number of detected faces. It's a simple and effective solution for face detection tasks.

Features

Face Detection: Detect faces in images or live webcam feeds.

Image Processing: Resize, crop, and manipulate images.

Edge Detection: Highlight edges using the Canny algorithm.

Real-Time Processing: Apply OpenCV operations to video streams.

---

Prerequisites

Ensure you have the following installed:

1. Python 3.6 or later


2. OpenCV library


3. Other dependencies (install using the requirements file)




---

Installation

1. Install Python on Windows

  1. Download Python:



  2. Install Python:

During installation, check the box "Add Python to PATH".

Complete the installation


2. Install OpenCV for Python

  1. Open Command Prompt: Press Win + R, type cmd, and press Enter.


  2. Install OpenCV using pip:

     pip install opencv-python
     pip install opencv-contrib-python  # For advanced features

Usage

Face Detection and Counting

1. Place your cctv in the input_cctv.


2. Run the script:


3. Output:

The total count of faces detected will be displayed.






